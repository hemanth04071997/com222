package com.virtusa.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.DAO.ApplicationDAOImp;

@Controller
public class ApplicationController
{

	
	@RequestMapping("/ApplicationDisplay")
	public ModelAndView view() {
		ModelAndView model=new ModelAndView("AppliedDisplayAll");
		
		model.addObject("ApplicationData",new ApplicationDAOImp().retrive() );
		return model;
	}
}

