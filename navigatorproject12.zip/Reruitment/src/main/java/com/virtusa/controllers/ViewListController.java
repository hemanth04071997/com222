package com.virtusa.controllers;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.DAO.EmployeeDAOImp;
import com.virtusa.models.EmployeeData;

@Controller
public class ViewListController {
@RequestMapping("/EmployeeDisplay")
public ModelAndView view() {
	ModelAndView model=new ModelAndView("EmployeeDisplayAll");
	
	model.addObject("EmployeeData",new EmployeeDAOImp().retrive() );
	return model;
}
}
