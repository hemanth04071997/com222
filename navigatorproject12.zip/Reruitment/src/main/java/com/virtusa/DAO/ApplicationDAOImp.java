package com.virtusa.DAO;
import java.util.List;
import com.virtusa.models.*;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.virtusa.DAO.*;

public class ApplicationDAOImp implements ApplicationDAO
{
	public  List<ApplicationData> retrive() {
		// TODO Auto-generated method stub
		 List<ApplicationData> results =null;
		Session session  = HibernateUtils.getSession();
		try {
            session.getTransaction().begin();
            String hql = " from ApplicationData";
            Query query = session.createQuery(hql);
           results = query.list();
           System.out.println(results);
            /*List < EmployeeData > students = session.createQuery("FROM EmployeeData E WHERE E.id =:id").list();*/
            /*students.forEach(s-> System.out.println(s.getFirstName()));*/
            session.getTransaction().commit();}
		
	catch(Exception ae) {
		
	}
		return results;
	}
}
