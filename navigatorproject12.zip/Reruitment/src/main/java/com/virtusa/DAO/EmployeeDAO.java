package com.virtusa.DAO;
import java.util.List;

import com.virtusa.models.*;
public interface EmployeeDAO {
public List<EmployeeData> retrive();
}
