package com.virtusa.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.virtusa.models.EmployeeData;

public class EmployeeDAOImp implements EmployeeDAO{


	

	public  List<EmployeeData> retrive() {
		// TODO Auto-generated method stub
		 List<EmployeeData> results =null;
		Session session  = HibernateUtils.getSession();
		try {
            session.getTransaction().begin();
            String hql = " from EmployeeData";
            Query query = session.createQuery(hql);
           results = query.list();
            /*List < EmployeeData > students = session.createQuery("FROM EmployeeData E WHERE E.id =:id").list();*/
            /*students.forEach(s-> System.out.println(s.getFirstName()));*/
            session.getTransaction().commit();}
		
	catch(Exception ae) {
		
	}
		return results;
	}
}
