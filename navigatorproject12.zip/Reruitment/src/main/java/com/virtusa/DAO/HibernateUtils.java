package com.virtusa.DAO;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

import com.virtusa.models.EmployeeData;


import org.hibernate.cfg.Configuration;
public class HibernateUtils {
 
	private static SessionFactory factory; 
	
	
	
   /* private static final SessionFactory sessionFactory = buildSessionFactory();
 
    // Hibernate 5:
    private static SessionFactory buildSessionFactory() {
        try {
            // Create the ServiceRegistry from hibernate.cfg.xml
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()//
                    .configure("hibernate.cfg.xml").build();
 
            // Create a metadata sources using the specified service registry.
            Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
 
            return metadata.getSessionFactoryBuilder().build();
        } catch (Throwable ex) {
         
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
 
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
 
    public static void shutdown() {
        // Close caches and connection pools
        getSessionFactory().close();
    }*/
	public static Session getSession() {
		Session session =null;
		try {
	         /*factory = new AnnotationConfiguration().
	                   configure().
	                   //addPackage("com.xyz") //add package if used.
	                   addAnnotatedClass(EmployeeData.class).
	                   buildSessionFactory();*/
			Configuration config=new Configuration().configure("hibernate.cfg.xml");
			factory=config.buildSessionFactory(new StandardServiceRegistryBuilder()
                    .applySettings(config.getProperties())
                    .build());
	        session = factory.openSession();
	        if(session==null)
				 System.out.println("null");
	      } catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	      }
		
		return session;
	}
	
			
}