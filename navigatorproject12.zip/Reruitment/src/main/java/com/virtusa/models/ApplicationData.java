package com.virtusa.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="applicationtable")
public class ApplicationData 
{
	@Id
	@Column(name="FirstName")
  private String firstName;
	@Id
	@Column(name="LastName")
  private String lastName;
	@Id
	@Column(name="Status")
  private String status;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "ApplicationData [firstName=" + firstName + ", lastName=" + lastName + ", status=" + status + "]";
}
}
